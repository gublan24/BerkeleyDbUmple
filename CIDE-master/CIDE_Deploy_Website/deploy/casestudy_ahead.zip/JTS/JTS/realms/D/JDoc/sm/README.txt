BACK contains the following files:
 CVS directory
 Build.class
 Build.java
 cleanlist
 sm.layer -> original layer
 sm.java
 