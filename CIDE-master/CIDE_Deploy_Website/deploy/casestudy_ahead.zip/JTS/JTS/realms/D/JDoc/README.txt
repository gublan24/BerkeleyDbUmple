Date: July 18, 2001

Current implementation can parse sm and layers as well.

Pending to be implemented : sm, java.

