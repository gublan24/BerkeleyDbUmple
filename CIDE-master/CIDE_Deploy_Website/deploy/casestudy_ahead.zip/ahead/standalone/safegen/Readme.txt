
To run you'll need to have the following jars in your class path. 
they should be included in AHEAD's lib

jdom.jar
bcel-5.1.jar
guidsl.jar
safegen.jar
sat4j.jar
classreader.jar

E.g Command:

$ java ProgramCube.Validation.SafeComposition.SafeCompositionValidator -md -f -s "C:\cygwin\home\Sahil\projects\safegen\examples\GPL2D.plm"


