import_ "b.h"

class_::foobar() { }
