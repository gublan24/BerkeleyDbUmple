import_ "a.h"

void class_::foo() { }

