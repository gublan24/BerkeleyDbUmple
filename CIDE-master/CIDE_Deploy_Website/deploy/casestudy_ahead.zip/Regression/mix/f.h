import_ "c.h"

class_::baz() { }
