import_ "c.h"

class class_ : super_ {
		int y;
		void bar();
		void biff();
}
