import_ "a.h"
import_ "b.h"

class class_ {
		int x;
		void bar();
}
