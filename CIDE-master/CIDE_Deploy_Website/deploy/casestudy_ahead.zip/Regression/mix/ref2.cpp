import_ "c.h"

class class_ : super_ {
		int z;
		int huh( int h );
}
