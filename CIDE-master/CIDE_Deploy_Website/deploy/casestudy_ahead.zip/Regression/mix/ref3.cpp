class class_ {
   int don;
	float batory();
}
