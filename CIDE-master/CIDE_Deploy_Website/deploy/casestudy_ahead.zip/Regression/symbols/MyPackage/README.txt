This directory, MyPackage, exists solely so that automatic package detection
can be detected during symbol table testing.
