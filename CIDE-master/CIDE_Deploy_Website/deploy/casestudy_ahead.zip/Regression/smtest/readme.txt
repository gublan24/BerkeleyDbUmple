this is a directory of regression tests for the sm layer.
Just run regress.bat, and it will print out the names
of the tests it is performing, otherwise it runs silently.

to build dsml (a language that includes the sm layer), run
newsm.bat  (you will need to move it to the languages directory
for it to work properly).
