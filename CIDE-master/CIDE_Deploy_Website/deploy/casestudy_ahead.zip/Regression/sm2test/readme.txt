this is a directory of regression tests for the sm2 layer.
Just run regress.bat, and it will print out the names
of the tests it is performing, otherwise it runs silently.

To run the tests, you will need to build the njb2 (new jak basic 2) 
preprocessor.  to do so, go to the JTS/languages directory and type:

   > java Bali.Main njb2
   > cd njb2
   > javac Build.java
   > java njb2.Build


